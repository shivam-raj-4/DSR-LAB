N1<-c(1,2,3,4,5)
str1<-c("hi","how","are","u")
real_num<-c(1.5,2.3,4.5)
res_list<-list(N1,str1,real_num)
res_list